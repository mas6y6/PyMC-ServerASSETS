PyOpenSSL
=========
.. warning::
    DEPRECATED: This module is deprecated and will be removed in urllib3 v2.1.0.
    Read more in this `issue <https://github.com/urllib3/urllib3/issues/2680>`_.

.. automodule:: urllib3.contrib.pyopenssl
    :members:
    :undoc-members:
    :show-inheritance:
